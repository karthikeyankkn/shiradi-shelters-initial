<?php
  
  $email = $_POST['email'];
  if($_POST['submit'] == 'Submit')
  {
    
    $itot="Quadrant_brochure@tvh.in";
    $headers = 'MIME-Version: 1.0' . "\r\n";
	$headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
	$headers .= 'From: '.$itot."\r\n";	
	$to = "sales@tvh.in";
	$headers .= ' ' . "\r\n";
	
	$subject = "Quadrant Property Broucher Download";
	$message = "<html><body>";
			$message .= "<br/>";
			$message .= "Customer Email-id:".$email."<br/>";
			$message .= "<br/>";
			$message .= "</body></html>";

			
	mail($to, $subject, $message, $headers);
	echo 1;
	}
  else
	{
	echo 0;
	}
  ?>