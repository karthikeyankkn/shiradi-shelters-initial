<!DOCTYPE html>
<html><head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
	<title>Quadrant - Thankyou Page</title>
    
    <!--pageMeta-->

    <!-- Loading Bootstrap -->
    <link href="http://quadrant.tvh.in/css/bootstrap.css" rel="stylesheet">
	
    <!-- Loading Elements Styles -->   
    <link href="http://quadrant.tvh.in/css/style.css" rel="stylesheet">
	
	<!-- Loading Magnific-Popup Styles --> 
    <link href="http://quadrant.tvh.in/css/magnific-popup.css" rel="stylesheet"> 
	   
    <!-- Loading Font Styles -->
    <link href="http://quadrant.tvh.in/css/iconfont-style.css" rel="stylesheet">

    <!-- WOW Animate-->
    <link href="http://quadrant.tvh.in/scripts/animations/animate.css" rel="stylesheet">
    
    <!-- Datepicker Styles -->   
    <link href="http://quadrant.tvh.in/css/bootstrap-datepicker3.min.css" rel="stylesheet">

	<!-- Favicons --><!--[if lt IE 9]>
<link rel='stylesheet' id='twentythirteen-ie-css'  href='http://demos.patternsinthecloud.com/electric-carousel/wp-content/themes/twentythirteen/css/ie.css?ver=2013-07-18' type='text/css' media='all' />
<![endif]-->
   <!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
    <!--[if lt IE 9]>
      <script src="http://quadrant.tvh.in/scripts/html5shiv.js"></script>
      <script src="http://quadrant.tvh.in/scripts/respond.min.js"></script>
    <![endif]-->
    
    <!--headerIncludes-->
    <!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','//connect.facebook.net/en_US/fbevents.js');

fbq('init', '899909930080787');
fbq('track', "PageView");</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=899909930080787&ev=PageView&noscript=1"
/>
fbq('track', 'Lead')   //*tvh quadrant*//
fbq('track', 'CompleteRegistration')  //*on the signup & thank u page*//
</noscript>
<!-- End Facebook Pixel Code -->
    <!-- Google Tag Manager -->
    <noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-T8HZNL"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    '//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-T8HZNL');</script>
    <!-- End Google Tag Manager -->
</head>
<body data-spy="scroll" data-target=".navMenuCollapse">

   

    <div id="wrap">

	    <!-- NAVIGATION INFO 3 -->
		<nav class="navbar navbar-slide navbar-fixed-top bg-color1 dark-bg" style="background-color:#000;">
			<div class="container"> 
				<div class="info-header left"><img src="http://quadrant.tvh.in/images/quadrant_logo.png" alt="logo" width="140"></div>
				<button class="round-toggle navbar-toggle menu-collapse-btn collapsed" data-toggle="collapse" data-target=".navMenuCollapse"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<div class="collapse navbar-collapse navMenuCollapse">
					<ul class="nav">
						<li><a href="http://quadrant.tvh.in/index.html">Why Adyar</a></li>
						<li><a href="http://quadrant.tvh.in/index.html">Highlights</a></li>
						<li><a href="http://quadrant.tvh.in/index.html">Broucher</a></li>
                        <li><a href="http://quadrant.tvh.in/index.html">Enquire</a></li>
					</ul>
				</div>
			</div>
		</nav>
        <section id="steps-path">
    		<div class="container">
            <div class="sep-bottom text-center">
          
 
 
<!-- include your own success html here -->
 
 
 
<h2>Thank you for contacting us. We will be in touch with you very soon.</h2>
 
 
 
<a class="btn btn-lg btn-primary goto" href="http://quadrant.tvh.in/">Back Home</a>
</div>
</div>
        </section>
        <footer id="footer-list-subscribe" class="dark-bg bg-color1">
    		<div class="container"> 
				
				<div class="row">
				<div class="col-md-6 col-md-push-6 text-right">
					
				</div>
				<div class="col-md-6 col-md-pull-6"> 
					<span class="editContent">&copy; 2016 <a href="http://www.tvh.in/" target="_blank">True Value Homes</a>. <br>All Rights Reserved </span></div>
			</div>
			</div>
		</footer>
        </div>

	<!-- MODALS END-->
	 

    <!-- JavaScript --> 
	<script src="http://quadrant.tvh.in/scripts/jquery-1.11.2.min.js"></script> 
	<script src="http://quadrant.tvh.in/scripts/bootstrap.min.js"></script> 
	<script src="http://quadrant.tvh.in/scripts/jquery.validate.min.js"></script>
	<script src="http://quadrant.tvh.in/scripts/smoothscroll.js"></script> 
	<script src="http://quadrant.tvh.in/scripts/jquery.smooth-scroll.min.js"></script> 
	<script src="http://quadrant.tvh.in/scripts/placeholders.jquery.min.js"></script> 
	<script src="http://quadrant.tvh.in/scripts/jquery.magnific-popup.min.js"></script>
	<script src="http://quadrant.tvh.in/scripts/jquery.counterup.min.js"></script>
	<script src="http://quadrant.tvh.in/scripts/waypoints.min.js"></script>
	<script src="http://quadrant.tvh.in/scripts/video.js"></script>
	<script src="http://quadrant.tvh.in/scripts/bigvideo.js"></script>
    <script src="http://quadrant.tvh.in/scripts/animations/wow.min.js"></script>
    <script src="http://quadrant.tvh.in/scripts/jquery.jCounter-0.1.4.js"></script>
    <script src="http://quadrant.tvh.in/scripts/bootstrap-datepicker.min.js"></script>
	<script src="http://quadrant.tvh.in/scripts/custom.js"></script>
	
	


	


</body>
</html>