$(function() {

$("#bro_submit").click(function() {
var submit = "Submit";
var emailid = $("#email").val();
var pattern = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
if(emailid =='')
{
    		$("#display_error").show();
			$("#display_error").html("<p style='color:#ff0000'>Enter Email-ID</p>"); 
			$("#brop").hide();

}
else if(!pattern.test(emailid))
{
			$("#display_error").show();
    		$("#display_error").html("<p style='color:#ff0000'>Enter Valid Email-ID</p>"); 
			$("#brop").hide();
}
else
{
$("#brop").hide();
$.ajax({
type: "POST",
dataType: 'json',
url: "register/reg_save.php",
data:{ email: emailid, submit: submit },
cache: true,
success: function(data){
if(data == 0)
		{
    		$("#display_error").show();
			$('#email').val(''); 
			$("#display_error").html("<p style='color:#ff0000; font-weight:bold;'>Register not successfully</p>");
			
        }
 else 
		{
			$("#display_error").show();
			$('#email').val('');  
            $(".input-group").hide();
            $("#download_bro").show();
       }
 
}  
});
}
return false;
});
});