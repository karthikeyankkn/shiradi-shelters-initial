/*
 *	jQuery electriccarousel 1.0.2
 *
 *	Copyright (c) 2013 Jonathan Baltazar
 */
(function($) {
	
	$.fn.electriccarousel = function(options) {
		var self = this;
		
		
		/*
		 * Properties
		 */
		this.$ = $(this);
		if (this.$.length < 1) return;
		this.defaultOptions = {
			animationDuration: 1000,
			autoPlay: true,
			controls: true,
			className: '',
			delay: 3000,
			xsmallHeight: null,
			smallHeight: null,
			mediumHeight: null,
			largeHeight: null,
			inactiveOpacity: 0.3,
			layout: 'full-width',
			responsive: true,
			scriptPath: null,
			selector: '> *',
			sizes: [{width: 400, height: 400}],
			startIndex: 0,
			width: '100%'
		};
		options = $.extend(self.defaultOptions, options);
		this.animating = false;
		this.animation = null;
		this.playState = 'stop';
		this.playTimer = null;
		this.resizeInterval = null;
		this.$.addClass('electriccarousel').addClass(options.layout);
		this.$anchor = $('<div class="electriccarousel-anchor"></div>').addClass(options.layout);
		this.$viewer = $('<div class="electriccarousel-viewer"></div>').addClass(options.layout);
		
		
		/*
		 * Methods
		 */
		
		this.calcOffset = function(index) {
			var relPos = 0;
			for (var i = 0; i < index; i++) {
				relPos += $(self.$items.get(i)).outerWidth(true);
			}
			var $item = $(self.$items.get(index));
			var itemWidth = $item.outerWidth(true);
			var viewerWidth = self.$viewer.width();
			var offset = (viewerWidth - itemWidth)/2 - relPos;
			return offset;
		};
		
		this.fillViewer = function(index) { 
			var targetIndex = (index == null)? self.currentIndex: index;
			var viewerWidth = self.$viewer.width();
			var threshold = parseInt(viewerWidth/4);
			var indexOffset = 0;
			var leftOffset = 0;
			var $item = $(self.$items.get(targetIndex));
			// Left side
			var bleedLeft = 
				viewerWidth - (viewerWidth - $item.outerWidth(true))/2;
			if (bleedLeft > -threshold) {
				for (var i = targetIndex-1; i >= 0; i--) {
					bleedLeft -= $(self.$items.get(i)).outerWidth(true);
					if (bleedLeft < -threshold) {
						break;
					}
				}
				if (bleedLeft > -threshold) {
					for (var i = self.$items.length-1; i > targetIndex; i--) {
						$item = $(self.$items.get(i));
						leftOffset -= $item.outerWidth(true);
						self.$.prepend($item);
						indexOffset += 1;
						break;
						if ((bleedLeft + leftOffset) < -threshold) {
							break;
						}
					}
					self.$items = self.$.find('> .electriccarousel-item');
				}
			}
			// Right side
			var bleedRight = 
				(viewerWidth - $item.outerWidth(true))/2 - viewerWidth;
			if (bleedRight < threshold) {
				var len = self.$items.length;
				for (var i = targetIndex+1; i < len; i++) {
					bleedRight += $(self.$items.get(i)).outerWidth(true);
					if (bleedRight > threshold) {
						break;
					}
				}
				if (bleedRight < threshold) {
					for (var i = 0; i < targetIndex; i++) {
						$item = $(self.$items.get(i));
						leftOffset += $item.outerWidth(true);
						self.$.append($item);
						indexOffset -= 1;
						if ((bleedRight + leftOffset) > threshold) {
							break;
						}
					}
					self.$items = self.$.find('> .electriccarousel-item');
				}
			}
			// Adjust left offset
			if (leftOffset != 0) {
				var currentLeft = parseInt(self.$.css('left'));
				self.$.css('left', (currentLeft + leftOffset) + 'px');
			}
			return indexOffset;
		};
		
		this.getResponsiveHeight = function() {
			var width = $(window).width();
			if (width >= 1200 && options.largeHeight != null) {
				// Large
				return options.largeHeight;
			} else if (width >= 992 && options.mediumHeight != null) {
				// Medium
				return options.mediumHeight;
			} else if (width >= 768 && options.smallHeight != null) {
				// Small
				return options.smallHeight;
			}
			// XSmall
			return options.xsmallHeight;
		};
		
		this.getScriptPath = function() {
			var path = '';
			$('script').each(function() {
				var search = /jquery\.electriccarousel\b[^\/]*\.js/;
				var pos = this.src.search(search);
				if (pos > -1) {
					path = this.src.substr(0, pos);
					return false;
				}
			});
			return path;
		};
		
		this.goTo = function(index) {
			self.currentIndex += self.fillViewer(index);
			var left = self.calcOffset(self.currentIndex);
			self.$.css('left', left + 'px');
			self.$items.not(self.$items[self.currentIndex]).removeClass('active').css('opacity', options.inactiveOpacity);
			self.$items.eq(self.currentIndex).addClass('active').css('opacity', 1);
			self.$.trigger('afterSlide');
		};
		
		this.getVisibleItems = function(index) {
			var targetIndex = (index == null)? self.currentIndex: index;
			var items = [];
			var viewerWidth = self.$viewer.width();
			var $targetItem = $(self.$items.get(targetIndex));
			items.push($targetItem);
			var bleedLeft 
				= viewerWidth - (viewerWidth + $targetItem.outerWidth(true))/2;
			for (var i = targetIndex-1; i >= 0; i--) {
				if (bleedLeft < 0) {
					break;
				}
				var $item = $(self.$items.get(i));
				bleedLeft -= $item.outerWidth(true);
				items.push($item);
			}
			var bleedRight 
				= (viewerWidth + $targetItem.outerWidth(true))/2 - viewerWidth;
			for (var i = targetIndex+1; i < self.$items.length; i++) {
				if (bleedRight > 0) {
					break;
				}
				var $item = $(self.$items.get(i));
				bleedRight += $item.outerWidth(true);
				items.push($item);
			}
			return items;
		};
		
		this.loadLazyImage = function(image) {
			var $img = $(image);
			var lazySrc = $img.attr('data-lazy-src');
			if (lazySrc) {
				var image = new Image();
				image.onload = function() {
					$img.attr('src', lazySrc);
					var responsiveHeight = self.getResponsiveHeight();
					if (responsiveHeight == null) {
						$img.attr('width', this.width).css('width', this.width + 'px');
						$img.attr('height', this.height).css('height', this.height + 'px');
					} else {
						var width = this.width*responsiveHeight/this.height;
						$img.attr('width', width).css('width', width + 'px');
						$img.attr('height', responsiveHeight).css('height', responsiveHeight + 'px');
					}
					$img.removeAttr('data-lazy-src');
					$img.removeClass('lazy-image').addClass('electriccarousel-image');
					$img.css('opacity', 0.0);
					if ($img.hasClass('electriccarousel-item') && !$img.hasClass('active')) {
						$img.fadeTo(options.animationDuration, options.inactiveOpacity);
					} else {
						$img.fadeTo(options.animationDuration, 1);
					}
					self.resize();
				};
				image.src = lazySrc;
			} else {
				var $children = $img.find('img.lazy-image');
				if ($children.length > 0) {
					$children.each(function() {
						self.loadLazyImage(this);
					});
				}
			}
		};
		
		this.loadVisible = function() {
			var visible = self.getVisibleItems();
			for (var i = 0; i < visible.length; i++) {
				self.loadLazyImage(visible[i]);
			}
		};
		
		this.pause = function() {
			clearInterval(self.playTimer);
			self.playState = 'pause';
		};
		
		this.play = function() {
			clearInterval(self.playTimer);
			self.playTimer = setInterval(function() {
				if ($(self.$items[self.currentIndex]).find('.lazy-image').length < 1) {
					self.$.trigger('next');
				}
			}, options.delay);
			self.playState = 'play';
		};
		
		this.stop = function() {
			clearInterval(self.playTimer);
			self.playState = 'stop';
		};
		
		this.resize = function() {
			var width = 0;
			var height = 0;
			var responsiveHeight = self.getResponsiveHeight();
			self.$items.each(function() {
				var $item = $(this);
				if (responsiveHeight != null) {
					var itemResponsiveHeight = $item.data('responsive-height');
					if (responsiveHeight != itemResponsiveHeight) {
						if ($item.hasClass('electriccarousel-image')) {
							$item.css('width', '').css('height', responsiveHeight + 'px')
								.removeAttr('width').attr('height', responsiveHeight);
						} else {
							$item.find('.electriccarousel-image')
								.css('width', '').css('height', responsiveHeight + 'px')
								.removeAttr('width').attr('height', responsiveHeight);
							$item.find('.lazy-image')
								.css('width', responsiveHeight + 'px')
								.css('height', responsiveHeight + 'px')
								.attr('width', responsiveHeight)
								.attr('height', responsiveHeight);
						}
						$item.data('responsive-height', responsiveHeight);
					}
				}
				width += $item.outerWidth(true);
				height = Math.max(height, $item.outerHeight(true));
			});
			self.$items.each(function() {
				var $item = $(this);
				var top = (height - $item.outerHeight())/2;
				$item.css('top', top + 'px');
			});
			this.$.css('width', width + 'px');
			this.$.css('height', height + 'px');
			this.$viewer.css('width', $(window).width() + 'px');
			this.$viewer.css('height', height + 'px');
			this.$anchor.css('height', height + 'px');
			var $parent = this.$anchor.parent();
			var offset = -($parent.offset().left + parseInt($parent.css('padding-left')));
			this.$anchor.css('left', offset + 'px');
			this.goTo(self.currentIndex);
		};
		
		this.scrollTo = function(index) {
			index += self.fillViewer(index);
			var left = self.calcOffset(index);
			if (self.animating) {
				self.$.stop(true);
			}
			self.animating = true;
			self.animation = self.$.animate(
				{
					'left': left
				}, 
				{
					duration: options.animationDuration,
					complete: function() {
						self.animating = false;
						self.$.trigger('afterSlide');
					}
				}
			);
			self.$items.not(self.$items[index]).removeClass('active').stop(true).fadeTo(options.animationDuration, options.inactiveOpacity);
			self.$items.eq(index).addClass('active').stop(true).fadeTo(options.animationDuration, 1);
			self.currentIndex = index;
		};
		
		
		/*
		 * Initialization
		 */
		if (options.scriptPath == null) {
			options.scriptPath = self.getScriptPath();
		}
		self.currentIndex = options.startIndex;
		
		
		/*
		 * Anchor
		 */
		self.$anchor.append(self.$viewer).insertBefore(self.$);
		
		
		/*
		 * Viewer
		 */
		self.$viewer.css('width', options.width).css('height', self.getResponsiveHeight()).append(self.$);
		if (options.className) {
			self.$viewer.addClass(options.className);
		}
		
		
		/*
		 * Events
		 */
		self.$.bind('prev', function() {
			self.scrollTo(self.currentIndex-1);
		});
		self.$.bind('next', function() {
			self.scrollTo(self.currentIndex+1);
		});
		self.$.bind('afterSlide', function() {
			self.loadVisible();
		});
		self.$.bind('resize', function() {
			self.resize();
		});
		self.$.bind('play', function() {
			self.play();
		});
		self.$.bind('pause', function() {
			self.pause();
		});
		self.$.bind('stop', function() {
			self.stop();
		});
		self.$.bind('touchstart mousedown', function () {
			self.$.trigger('pause');
		});
		self.$.bind('touchend mouseup', function () {
			self.scrollTo(self.currentIndex);
			self.$.trigger('play');
		});
		self.$.swipe(function (evt, dx, dy) {
			if (dx > 80) {
				self.$.trigger('prev');
			} else if (dx < -80) {
				self.$.trigger('next');
			} else if (Math.abs(dy) > 30) {
				var targetScroll = $(document.body).scrollTop() - 5*dy;
				$(document.body).animate({
					'scrollTop': targetScroll
				}, 'fast');
			}
		}, 80, 30);
		self.$.bind('swipe-step', function (evt, dx, dy) {
			if (dx < 80 && ! self.animating ) {
				var left = self.calcOffset(self.currentIndex) + dx;
				self.$.css('left', left);
			}
		});
		self.$.hover(
			function() {
				if (self.playState == 'play') {
					self.pause();
				}
			},
			function() {
				if (self.playState == 'pause') {
					self.play();
				}
			}
		);
		
		
		/*
		 * Lazy links
		 */
		$lazyLinks = self.$.find('a.lazy-link');
		$lazyLinks.each(function() {
			var $a = $(this);
			var $img = $('<img class="lazy-image" />')
				.attr('src', options.scriptPath + '../images/empty.png')
				.attr('data-lazy-src', $a.attr('href'))
				.attr('alt', $a.text())
				.attr('title', $a.text());
			var responsiveHeight = self.getResponsiveHeight();
			if (responsiveHeight == null) {
				$img.attr('width', options.sizes[0].width)
					.attr('height', options.sizes[0].height);
			} else {
				var width = options.sizes[0].width*responsiveHeight/options.sizes[0].height;
				$img.attr('width', width)
					.attr('height', responsiveHeight);
			}
			$img.insertAfter(this);
		});
		$lazyLinks.remove();
		
		
		/*
		 * Items
		 */
		self.$items = self.$.find(options.selector);
		self.$items.addClass('electriccarousel-item');
		
		
		/*
		 * Controls
		 */
		if (options.controls) {
			// Left paddle
			var $paddleLeft = $('<div' 
				+ ' class="electriccarousel-paddle electriccarousel-paddle-left"'
				+ '></div>'
			);
			$paddleLeft.click(function() {
				self.$.trigger('prev');
			});
			// Append control
			self.$viewer.append($paddleLeft);
			// Right paddle
			var $paddleRight = $('<div' 
				+ ' class="electriccarousel-paddle electriccarousel-paddle-right"'
				+ '></div>'
			);
			$paddleRight.click(function() {
				self.$.trigger('next');
			});
			// Append control
			self.$viewer.append($paddleRight);
		}
		
		
		/*
		 * Window resize
		 */
		$(window).resize(function() {
			clearInterval(self.resizeInterval);
			self.resizeInterval = setTimeout(function() {
				self.resize();
			}, 400);
		});
		
		
		/*
		 * Start the carousel
		 */
		self.goTo(options.startIndex);
		self.$.css('visibility', 'visible');
		if (options.autoPlay) {
			self.play();
		}
		self.resize();
	};
	
})(jQuery);
