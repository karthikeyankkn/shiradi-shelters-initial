var electriccarousel_options = [];
jQuery(function($) {
	$('.electriccarousel').each(function () {
		var $carousel = $(this);
		$carousel.electriccarousel(electriccarousel_options[$carousel.data('instance-id')]);
	});
});
